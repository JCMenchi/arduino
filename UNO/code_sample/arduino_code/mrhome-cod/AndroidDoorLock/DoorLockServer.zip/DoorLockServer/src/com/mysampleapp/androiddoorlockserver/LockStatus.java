package com.mysampleapp.androiddoorlockserver;

public class LockStatus {

    public boolean getLockStatus() {
        return myLockStatus;
    }

    public void setMyVar(boolean myLockStatus) {
        this.myLockStatus = myLockStatus;
    }

    private boolean myLockStatus = false;
    private static LockStatus instance;

    static {
        instance = new LockStatus();
    }

    private LockStatus() {
    }

    public static LockStatus getInstance() {
        return LockStatus.instance;
    }

}