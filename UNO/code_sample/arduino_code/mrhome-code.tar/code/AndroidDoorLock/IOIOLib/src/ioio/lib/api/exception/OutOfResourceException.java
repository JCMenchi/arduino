/***
 * Excerpted from "Programming Your Home",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material, 
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose. 
 * Visit http://www.pragmaticprogrammer.com/titles/mrhome for more book information.
***/
package ioio.lib.api.exception;

/**
 * The IOIO board does not have anymore of the requested resource. This
 * exceptions do not need to be handled if the client guarantees that the limits
 * on concurrent resource usage are never exceeded.
 */
public class OutOfResourceException extends RuntimeException {
	private static final long serialVersionUID = -4482605241361881899L;

	public OutOfResourceException(String msg) {
		super(msg);
	}
}